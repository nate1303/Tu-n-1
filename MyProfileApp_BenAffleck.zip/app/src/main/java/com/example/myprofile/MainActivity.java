package com.example.myprofile;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView avatar = findViewById(R.id.imageAvatar);
        TextView name = findViewById(R.id.textName);
        TextView address = findViewById(R.id.textAddress);

        // Sửa tên và địa chỉ theo ý bạn
        name.setText("Tên: Nguyễn Văn A");
        address.setText("Địa chỉ: Hồ Chí Minh");
    }
}