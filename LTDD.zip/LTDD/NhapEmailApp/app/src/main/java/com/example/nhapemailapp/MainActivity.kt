package com.example.nhapemailapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NhapEmailApp()
        }
    }
}

@Composable
fun NhapEmailApp() {
    var email by remember { mutableStateOf("") }
    var thongBao by remember { mutableStateOf("") }

    // Giao diện chính
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Nhập email của bạn") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            if (email.isEmpty()) {
                thongBao = "Email không hợp lệ"
            } else if (!email.contains("@")) {
                thongBao = "Email không đúng định dạng"
            } else {
                thongBao = "Bạn đã nhập email hợp lệ"
            }
        }) {
            Text("Kiểm tra email")
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(text = thongBao, style = MaterialTheme.typography.bodyLarge)
    }
}
