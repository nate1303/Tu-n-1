package com.example.thongtinnguoidungapp
import androidx.compose.foundation.text.KeyboardOptions
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview
import com.example.thongtinnguoidungapp.ui.theme.ThongTinNguoiDungAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ThongTinNguoiDungAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ThongTinNguoiDungScreen()
                }
            }
        }
    }
}

@Composable
fun ThongTinNguoiDungScreen() {
    var ten by remember { mutableStateOf("") }
    var tuoiText by remember { mutableStateOf("") }
    var ketQua by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = ten,
            onValueChange = { ten = it },
            label = { Text("Nhập tên") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = tuoiText,
            onValueChange = { tuoiText = it },
            label = { Text("Nhập tuổi") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )


        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                if (ten.isEmpty() || tuoiText.isEmpty()) {
                    ketQua = "⚠ Vui lòng nhập đầy đủ thông tin!"
                } else {
                    val tuoi = tuoiText.toIntOrNull()
                    if (tuoi == null || tuoi < 0) {
                        ketQua = "Tuổi phải là số nguyên dương!"
                    } else {
                        // Kiểm tra nhóm tuổi bằng if
                        val nhom = if (tuoi <= 2) {
                            "Em bé"
                        } else if (tuoi <= 6) {
                            "Trẻ em"
                        } else if (tuoi < 65) {
                            "Người lớn"
                        } else {
                            "Người già"
                        }
                        ketQua = "Xin chào $ten!\nTuổi của bạn là $tuoi.\nNhóm tuổi: $nhom"
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Kiểm tra")
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = ketQua,
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewThongTinNguoiDungScreen() {
    ThongTinNguoiDungAppTheme {
        ThongTinNguoiDungScreen()
    }
}
