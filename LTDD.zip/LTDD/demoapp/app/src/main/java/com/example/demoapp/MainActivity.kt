package com.example.demoapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputNumber = findViewById<EditText>(R.id.inputNumber)
        val btnCreate = findViewById<Button>(R.id.btnCreate)
        val errorMessage = findViewById<TextView>(R.id.errorMessage)
        val numberListContainer = findViewById<LinearLayout>(R.id.numberListContainer)

        btnCreate.setOnClickListener {
            val inputText = inputNumber.text.toString()
            numberListContainer.removeAllViews() // Xoá danh sách cũ
            errorMessage.visibility = TextView.GONE // Ẩn thông báo lỗi

            // Kiểm tra nếu nhập đúng số
            if (inputText.isNotEmpty() && inputText.toIntOrNull() != null) {
                val number = inputText.toInt()

                // Tạo danh sách từ 1 đến number
                for (i in 1..number) {
                    val btn = Button(this)
                    btn.text = i.toString()
                    btn.setBackgroundColor(resources.getColor(android.R.color.holo_red_light))
                    numberListContainer.addView(btn)
                }
            } else {
                // Dữ liệu không hợp lệ
                errorMessage.text = "Dữ liệu bạn nhập không hợp lệ"
                errorMessage.visibility = TextView.VISIBLE
            }
        }
    }
}
